import 'package:flutter/cupertino.dart';

class CategoriesModle {
  final String image;
  final String name;
  CategoriesModle({@required this.image, @required this.name});
}
