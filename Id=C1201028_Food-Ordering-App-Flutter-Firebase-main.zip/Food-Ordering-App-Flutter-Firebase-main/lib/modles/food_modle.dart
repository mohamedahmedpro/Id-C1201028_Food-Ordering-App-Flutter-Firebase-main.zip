import 'package:flutter/cupertino.dart';

class FoodModle{
  final String image;
  final String name;
  final int price;
  FoodModle({@required this.image,@required this.name,@required this.price});
}